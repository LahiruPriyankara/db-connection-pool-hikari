package com.lhu.dbconnectionpool;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DbConnectionPoolApplication {

	public static void main(String[] args) {
		SpringApplication.run(DbConnectionPoolApplication.class, args);
	}

}
