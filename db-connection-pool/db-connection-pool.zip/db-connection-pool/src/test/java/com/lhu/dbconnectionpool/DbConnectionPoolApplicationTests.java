package com.lhu.dbconnectionpool;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DbConnectionPoolApplicationTests {

	@Test
	void contextLoads() {
	}

}
